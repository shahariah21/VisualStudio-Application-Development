﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class InvoiceTotal
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtSubtotal = New System.Windows.Forms.TextBox()
        Me.txtDiscountPercent = New System.Windows.Forms.TextBox()
        Me.txtDiscountAmount = New System.Windows.Forms.TextBox()
        Me.txtTotal = New System.Windows.Forms.TextBox()
        Me.txtNumberOfInvoices = New System.Windows.Forms.TextBox()
        Me.txtTotalOfInvoices = New System.Windows.Forms.TextBox()
        Me.txtInvoiceAverage = New System.Windows.Forms.TextBox()
        Me.txtLargestInvoice = New System.Windows.Forms.TextBox()
        Me.txtSmallestInvoice = New System.Windows.Forms.TextBox()
        Me.txtMidPoint = New System.Windows.Forms.TextBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnClearTotals = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(60, 64)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(128, 32)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Subtotal:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(60, 159)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(238, 32)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Discount Percent:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(60, 255)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(238, 32)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Discount Amount:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(60, 351)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(86, 32)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Total:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(782, 56)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(264, 32)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Number of invoices:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(782, 140)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(228, 32)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Total of invoices:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(782, 224)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(222, 32)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Invoice average:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(782, 308)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(214, 32)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Largest invoice:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(782, 392)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(229, 32)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Smallest invoice:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(782, 476)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(131, 32)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Midpoint:"
        '
        'txtSubtotal
        '
        Me.txtSubtotal.Location = New System.Drawing.Point(360, 56)
        Me.txtSubtotal.Name = "txtSubtotal"
        Me.txtSubtotal.Size = New System.Drawing.Size(291, 38)
        Me.txtSubtotal.TabIndex = 1
        '
        'txtDiscountPercent
        '
        Me.txtDiscountPercent.Location = New System.Drawing.Point(360, 154)
        Me.txtDiscountPercent.Name = "txtDiscountPercent"
        Me.txtDiscountPercent.ReadOnly = True
        Me.txtDiscountPercent.Size = New System.Drawing.Size(291, 38)
        Me.txtDiscountPercent.TabIndex = 11
        Me.txtDiscountPercent.TabStop = False
        '
        'txtDiscountAmount
        '
        Me.txtDiscountAmount.Location = New System.Drawing.Point(360, 252)
        Me.txtDiscountAmount.Name = "txtDiscountAmount"
        Me.txtDiscountAmount.ReadOnly = True
        Me.txtDiscountAmount.Size = New System.Drawing.Size(291, 38)
        Me.txtDiscountAmount.TabIndex = 12
        Me.txtDiscountAmount.TabStop = False
        '
        'txtTotal
        '
        Me.txtTotal.Location = New System.Drawing.Point(359, 350)
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.ReadOnly = True
        Me.txtTotal.Size = New System.Drawing.Size(291, 38)
        Me.txtTotal.TabIndex = 13
        Me.txtTotal.TabStop = False
        '
        'txtNumberOfInvoices
        '
        Me.txtNumberOfInvoices.Location = New System.Drawing.Point(1147, 55)
        Me.txtNumberOfInvoices.Name = "txtNumberOfInvoices"
        Me.txtNumberOfInvoices.ReadOnly = True
        Me.txtNumberOfInvoices.Size = New System.Drawing.Size(291, 38)
        Me.txtNumberOfInvoices.TabIndex = 15
        Me.txtNumberOfInvoices.TabStop = False
        '
        'txtTotalOfInvoices
        '
        Me.txtTotalOfInvoices.Location = New System.Drawing.Point(1146, 138)
        Me.txtTotalOfInvoices.Name = "txtTotalOfInvoices"
        Me.txtTotalOfInvoices.ReadOnly = True
        Me.txtTotalOfInvoices.Size = New System.Drawing.Size(291, 38)
        Me.txtTotalOfInvoices.TabIndex = 16
        Me.txtTotalOfInvoices.TabStop = False
        '
        'txtInvoiceAverage
        '
        Me.txtInvoiceAverage.Location = New System.Drawing.Point(1146, 222)
        Me.txtInvoiceAverage.Name = "txtInvoiceAverage"
        Me.txtInvoiceAverage.ReadOnly = True
        Me.txtInvoiceAverage.Size = New System.Drawing.Size(291, 38)
        Me.txtInvoiceAverage.TabIndex = 17
        Me.txtInvoiceAverage.TabStop = False
        '
        'txtLargestInvoice
        '
        Me.txtLargestInvoice.Location = New System.Drawing.Point(1146, 306)
        Me.txtLargestInvoice.Name = "txtLargestInvoice"
        Me.txtLargestInvoice.ReadOnly = True
        Me.txtLargestInvoice.Size = New System.Drawing.Size(291, 38)
        Me.txtLargestInvoice.TabIndex = 18
        Me.txtLargestInvoice.TabStop = False
        '
        'txtSmallestInvoice
        '
        Me.txtSmallestInvoice.Location = New System.Drawing.Point(1146, 390)
        Me.txtSmallestInvoice.Name = "txtSmallestInvoice"
        Me.txtSmallestInvoice.ReadOnly = True
        Me.txtSmallestInvoice.Size = New System.Drawing.Size(291, 38)
        Me.txtSmallestInvoice.TabIndex = 19
        Me.txtSmallestInvoice.TabStop = False
        '
        'txtMidPoint
        '
        Me.txtMidPoint.Location = New System.Drawing.Point(1146, 474)
        Me.txtMidPoint.Name = "txtMidPoint"
        Me.txtMidPoint.ReadOnly = True
        Me.txtMidPoint.Size = New System.Drawing.Size(291, 38)
        Me.txtMidPoint.TabIndex = 20
        Me.txtMidPoint.TabStop = False
        '
        'btnCalculate
        '
        Me.btnCalculate.BackColor = System.Drawing.SystemColors.ControlLight
        Me.btnCalculate.Location = New System.Drawing.Point(620, 557)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(232, 53)
        Me.btnCalculate.TabIndex = 2
        Me.btnCalculate.Text = "&Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = False
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.SystemColors.ControlLight
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(913, 557)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(232, 53)
        Me.btnExit.TabIndex = 4
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'btnClearTotals
        '
        Me.btnClearTotals.BackColor = System.Drawing.SystemColors.ControlLight
        Me.btnClearTotals.Location = New System.Drawing.Point(1206, 557)
        Me.btnClearTotals.Name = "btnClearTotals"
        Me.btnClearTotals.Size = New System.Drawing.Size(232, 53)
        Me.btnClearTotals.TabIndex = 3
        Me.btnClearTotals.Text = "C&lear Totals"
        Me.btnClearTotals.UseVisualStyleBackColor = False
        '
        'InvoiceTotal
        '
        Me.AcceptButton = Me.btnCalculate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(16.0!, 31.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.CancelButton = Me.btnExit
        Me.ClientSize = New System.Drawing.Size(1572, 666)
        Me.Controls.Add(Me.btnClearTotals)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.txtMidPoint)
        Me.Controls.Add(Me.txtSmallestInvoice)
        Me.Controls.Add(Me.txtLargestInvoice)
        Me.Controls.Add(Me.txtInvoiceAverage)
        Me.Controls.Add(Me.txtTotalOfInvoices)
        Me.Controls.Add(Me.txtNumberOfInvoices)
        Me.Controls.Add(Me.txtTotal)
        Me.Controls.Add(Me.txtDiscountAmount)
        Me.Controls.Add(Me.txtDiscountPercent)
        Me.Controls.Add(Me.txtSubtotal)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "InvoiceTotal"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Invoice Total"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents txtSubtotal As TextBox
    Friend WithEvents txtDiscountPercent As TextBox
    Friend WithEvents txtDiscountAmount As TextBox
    Friend WithEvents txtTotal As TextBox
    Friend WithEvents txtNumberOfInvoices As TextBox
    Friend WithEvents txtTotalOfInvoices As TextBox
    Friend WithEvents txtInvoiceAverage As TextBox
    Friend WithEvents txtLargestInvoice As TextBox
    Friend WithEvents txtSmallestInvoice As TextBox
    Friend WithEvents txtMidPoint As TextBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents btnClearTotals As Button
End Class
