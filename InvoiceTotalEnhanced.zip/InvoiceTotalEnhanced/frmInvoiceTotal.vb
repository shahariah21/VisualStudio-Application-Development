﻿Imports System.Speech.Synthesis

Public Class InvoiceTotal

    Dim numberOfInvoices As Integer
    Dim totalOfInvoices As Decimal
    Dim invoiceAverage As Decimal
    Dim largestInvoice As Decimal
    Dim smallestInvoice As Decimal = 999999999
    Dim midPoint As Decimal
    Private synth As SpeechSynthesizer

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'The Parse method converts the text input from the txtSubtotal textbox to a Decimal; explicitly shows a string is being converted.'
        Dim subtotal As Decimal = Decimal.Parse(txtSubtotal.Text)
        'CDec is a function that explicitly converts a data type to a decimal with precision when using the strict type semantics.'
        'Dim subtotal As Decimal = CDec(txtSubtotal.Text)'
        Dim discountPercent As Decimal

        'CDec is a function that explicitly converts a data type to a decimal with precision when using the strict type semantics.'
        If subtotal >= 500 Then
            discountPercent = CDec(0.2)
        ElseIf subtotal >= 250 And subtotal < 500 Then
            discountPercent = CDec(0.15)
        ElseIf subtotal >= 100 And subtotal < 250 Then
            discountPercent = CDec(0.1)
        Else
            discountPercent = 0
        End If

        Dim discountAmount As Decimal = subtotal * discountPercent
        Dim invoiceTotal As Decimal = subtotal - discountAmount

        numberOfInvoices = numberOfInvoices + 1
        totalOfInvoices = totalOfInvoices + invoiceTotal
        invoiceAverage = totalOfInvoices / numberOfInvoices
        largestInvoice = Math.Max(largestInvoice, invoiceTotal)
        smallestInvoice = Math.Min(smallestInvoice, invoiceTotal)
        midPoint = (largestInvoice + smallestInvoice) / 2

        txtDiscountPercent.Text = FormatPercent(discountPercent)
        txtDiscountAmount.Text = FormatCurrency(discountAmount)
        txtTotal.Text = FormatCurrency(invoiceTotal)
        txtNumberOfInvoices.Text = numberOfInvoices.ToString
        txtTotalOfInvoices.Text = totalOfInvoices.ToString("C")
        txtInvoiceAverage.Text = invoiceAverage.ToString("C")
        txtLargestInvoice.Text = FormatCurrency(largestInvoice)
        txtSmallestInvoice.Text = FormatCurrency(smallestInvoice)
        txtMidPoint.Text = FormatCurrency(midPoint)

        txtSubtotal.Select()

        synth.SpeakAsync($"The total price of the invoice is {invoiceTotal.ToString("C")}")
    End Sub

    Private Sub frmInvoiceTotal_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        synth = New SpeechSynthesizer()
    End Sub

    Private Sub btnClearTotals_Click(sender As Object, e As EventArgs) Handles btnClearTotals.Click
        numberOfInvoices = 0
        totalOfInvoices = 0
        invoiceAverage = 0
        largestInvoice = 0
        smallestInvoice = 999999999
        midPoint = 0

        txtSubtotal.Text = ""
        txtDiscountPercent.Text = ""
        txtDiscountAmount.Text = ""
        txtTotal.Text = ""

        txtNumberOfInvoices.Text = ""
        txtTotalOfInvoices.Text = ""
        txtInvoiceAverage.Text = ""
        txtLargestInvoice.Text = ""
        txtSmallestInvoice.Text = ""
        txtMidPoint.Text = ""


    End Sub
End Class